@echo off
start C:\Windows\System32\main.cpl